<?php
/**
* @version		$Id: vm_all-in-one.php 2789 2011-02-28 12:41:01Z oscar $
* @package		Joomla
* @subpackage	Weblinks
* @copyright	Copyright (C) 2005 - 2010 Open Source Matters. All rights reserved.
* @license		GNU/GPL, see LICENSE.php
* Joomla! is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See COPYRIGHT.php for copyright notices and details.
*/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
JHTML::_( 'behavior.modal' ); 
?>

<H3>Virtuemart All in One defaut Paiement and modules</H3>
<P>To configure Paiement plugins <a class="modal" href="index.php?option=com_plugins&filter_type=vmpayment&tmpl=component">CLICK HERE</a></p>
<P>To configure Shipping plugins <a class="modal" href="index.php?option=com_plugins&filter_type=vmshipper&tmpl=component">CLICK HERE</a></p>